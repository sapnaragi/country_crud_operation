
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
 -->  <title>Modal</title>
</head>
<style>
.removeRow
{
 background-color: #A6ACAF;
    color:#FFFFFF;
}
</style>
<body>
  <div class="subcontainer" style="margin-top: 5%;margin-left:8%;">
      <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#country_modal">Add Country</button>
      <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#state_modal">Add State</button>
      <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#city_modal">Add City</button>

</div>
 <div class="container">
 <form name="bulk_action_form" action="" method="post" onSubmit="return delete_confirm();"/>
  <table class="table table-bordered" style="margin-top: 2%;">
    <thead>
       <tr>
        <th><button type="button" name="delete_all" id="delete_all" class="btn btn-danger">Delete</button></th>
        <th><input type="checkbox" id="select_all" value=""/>  
            <input type="submit" class="btn btn-danger" name="bulk_delete_submit" value="DELETE"/>  
        </th>    
        <th>Sr No.</th>
        <th>Countryname</th>
        <th colspan="2">Action</th>
      </tr>
    </thead>
   <tbody> 
      <tr>
          <?php  foreach ($country_name as $country){  ?>
                   <tr>
                        <td><input type="checkbox" class="delete_checkbox" value="<?php echo $country['id']?>" /></td>
                         <td><input type="checkbox" name="checked_id[]" class="checkbox" value="<?php echo $country['id']; ?>"/></td>

                        <td><?php echo  $country['id'];?></td>
                        <td><?php echo $country['name'];?></td>
                      <td> 
                        <input type="button" class="btn btn-success" value="Update" onclick="return update_modal('<?php echo $country['id']?>')">
                          <?php echo anchor('welcome/delete_records/'.$country['id'],"Delete",array('class'=>"btn btn-info"));?>
                     </td> 
                    </tr>
          <?php } ?> 
   </tbody>
   </table>
 </form>
 </div>

  <!-- Modal -->
  <div class="modal fade" id="country_modal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
            <form method="post" action="<?php echo base_url('welcome/savingdata');?>" id="country_form">
              <input type="text" name="countryname" id="countryname">
              <input type="hidden" id="countryid">
              <input type="submit" id="add" class="btn btn-success" value="ADD">
              <input type="button" id="upt" class="btn btn-info" value="UPDATE" onclick="return update_country_name();">
              <input type="hidden" name="country_id" id="country_id">
           </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

<!-- Modal -->
  <div class="modal fade" id="state_modal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
           <form method="post" action="<?php echo base_url('welcome/add_state');?>" id="state_form">
            <select name="country" id="country">
                 <?php  foreach ($country_name as $country){  ?>
                    <option value="<?php echo $country['id']; ?>"><?php echo $country['name']; ?></option>
                 <?php } ?> 
            </select>
            <input type="text" name="statename">
            <input type="submit" class="btn btn-success" value="ADD">
           </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

<!-- Modal -->
  <div class="modal fade" id="city_modal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add City</h4>
        </div>
        <div class="modal-body">
           <form method="post" action="<?php echo base_url('welcome/add_city');?>" id="state_form">
            <select name="country" name="cityname" id="city_country" onchange="getnextdata('get_state','city_country','state')">
               <option value="">Select Country</option>
                 <?php  foreach ($country_name as $country){  ?>
                    <option value="<?php echo $country['id']; ?>"><?php echo $country['name']; ?></option>
                 <?php } ?> 
            </select><br/>
             <select name="state" id="data_select" >
              <option value="">Select State</option>
              <?php  foreach ($state_name as $state){  ?>
                    <option value="<?php echo $state['id']; ?>"><?php echo $state['name']; ?></option>
                 <?php } ?> 
            </select>
             <input type="text" name="cityname">
             <input type="submit" class="btn btn-success" value="ADD">
           </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

<script type="text/javascript">
  function getnextdata(method,select_id,data_select){
    var id =  $('#'+select_id).val();
    // alert(id);
    var url = "<?php echo base_url('welcome/')?>"+method+'/'+id;
        $.get(url, function(response) {
           var data = JSON.parse(response);
           if(typeof data === 'object' && data !== null){
              $('#'+data_select + " option").remove();
                $.each(data, function(v) {
                    html = "<option value='" + data[v].id + "'>" + data[v].name + "</option>";
                  $('#'+data_select).append(html);
                });
             }
        });
  }
</script>
<script type="text/javascript">
  function update_modal(id){
 
    $('#country_id').val(id);
   
    $.ajax({
        type: "POST",
        url: "<?php echo base_url('welcome/get_data/')?>"+id,
        success: function(response){ 
        var data = JSON.parse(response);
           if(typeof data === 'object' && data !== null){
                $('#countryname').val(data.name);
                $('#countryid').val(data.id);
                $('#add').hide();
             }
        }
      });
    $("#country_modal").modal('show');
  }
</script>
<script type="text/javascript">
function update_country_name()
{
  var countryid=$("#countryid").val();
  var countryname=$("#countryname").val();
 $.ajax({
        type: "POST",
        url: "<?php echo base_url('Welcome/update_country_name')?>",
         data: {  
                'countryid': countryid,
                'countryname': countryname,
              },
        success: function(response){ 
         $('#country_modal').hide();
         location.reload(true);
        }
      });
}
</script>
<script type="text/javascript">
  $('.delete_checkbox').click(function(){
   //alert('hi');return false;
  if($(this).is(':checked'))
  {
   $(this).closest('tr').addClass('removeRow');
  }
  else
  {
   $(this).closest('tr').removeClass('removeRow');
  }
  });
</script>
<script type="text/javascript">
 $('#delete_all').click(function(){
  var checkbox = $('.delete_checkbox:checked');
  if(checkbox.length > 0)
  {
   var checkbox_value = [];
   $(checkbox).each(function(){
    checkbox_value.push($(this).val());
   // alert(checkbox_value);return false;
   });
   $.ajax({
    url:"<?php echo base_url(); ?>welcome/delete_all",
    method:"POST",
    data:{checkbox_value:checkbox_value},
    success:function(response)
    {
     $('.removeRow').fadeOut(1500);
    }
   })
  }
  else
  {
   alert('Select atleast one records');
  }
 });
</script>

<script type="text/javascript">
  function delete_confirm(){

    if($('.checkbox:checked').length > 0){
        var result = confirm("Are you sure to delete selected users?");
        if(result){
            return true;
        }else{
            return false;
        }
    }else{
        alert('Select at least 1 record to delete.');
        return false;
    }
}
    $('#select_all').on('click',function(){
        if(this.checked){
          //alert('d');
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.checkbox').on('click',function(){
        if($('.checkbox:checked').length == $('.checkbox').length){
            $('#select_all').prop('checked',true);
        }else{ 
            $('#select_all').prop('checked',false);
        }
    });

</script>


</body>
</html>

  