<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('welcome_model');
    }
    public function index(){
        $data = array();
        // If record delete request is submitted
        if($this->input->post('bulk_delete_submit')){
            // Get all selected IDs
            $ids = $this->input->post('checked_id');
             // If id array is not empty
            if(!empty($ids)){
                // Delete records from the database
                $delete = $this->welcome_model->delete($ids);
                
                // If delete is successful
                if($delete){
                    $data['statusMsg'] = 'Selected users have been deleted successfully.';
                }else{
                    $data['statusMsg'] = 'Some problem occurred, please try again.';
                }
            }else{
                $data['statusMsg'] = 'Select at least 1 record to delete.';
            }
        }
        // Get user data from the database
        $country_name = $this->welcome_model->getCountries();
        $state_name = $this->welcome_model->getStates();
        $data=array(
        'country_name'=>$country_name,
        'state_name'=>$state_name,
        'users'=>$this->welcome_model->getRows(),
        );
        $this->load->view('form/index', $data);
    }

    public function savingdata(){  
        $result = $this->welcome_model->save_country_name(); 
        redirect("Welcome");  
    } 
   
    public function add_state(){  
        $result = $this->welcome_model->add_state(); 
        redirect("welcome");  
    }  

    public function delete_records(){
        $id = $this->uri->segment('3');
        $result = $this->welcome_model->delete_data($id);
        redirect("Welcome");  
   } 

   public function get_state(){
        $id = $this->uri->segment('3');
        $data = $this->welcome_model->get_state($id);
        echo json_encode($data);
   }
   public function add_city(){
        $result = $this->welcome_model->add_city();
        redirect("welcome");
   }
   public function get_city(){
        $id = $this->uri->segment('3');
        $data = $this->welcome_model->get_city($id);
        echo json_encode($data);
   }
   public function get_data($id){
        $id = $this->uri->segment('3');
        $data = $this->welcome_model->get_data($id);
        // print_r( $data);exit;
        echo json_encode($data);
   }
   public function  update_country_name()
    {
        $id = $this->input->post('countryid');   
         
        $data = array(
                'name' => $this->input->post('countryname')
            ); 
        $this->db->where('Id', $id);

        if (!$this->db->update('countries',$data)) 
        {
            $hasError = $this->db->_error_message();
            echo $hasError;
        }
        else{
            redirect('welcome/index', 'refresh');
        }
    } 
    public function delete_all(){
        if($this->input->post('checkbox_value'))
        {
            $id=$this->input->post('checkbox_value');
             for($count = 0; $count < count($id); $count++)
               {
                $this->welcome_model->delete($id[$count]);
               }
        }
    }
    
    
} 