<?php
class Welcome_model extends CI_Model{
	
	function __construct(){
		parent::__construct();
	}

	function getCountries(){
		return $this->db->get('countries')->result_array();
 	}
    function getStates(){
        return $this->db->get('states')->result_array();
    }
  
  	function delete_data($id){
  		 if($this->db->delete("countries",array('id'=> $id))){
        	return "Data deleted from database!";
        }else{
        	return "Data doesn't deleted in database!";
        } 
	}
 
	function save_country_name(){
		$data = array(
                        'name'	=> $this->input->post('countryname'),  
                      );  
        if($this->db->insert('countries',$data)){
        	return "Data stored in database!";
        }else{
        	return "Data doesn't stored in database!";
        }
	}

 	function add_state(){
		$data = array(
                        'name'	=> $this->input->post('statename'),  
                        'country_id' => $this->input->post('country'),  
                      );  


        if($this->db->insert('states',$data)){
        	return "Data stored in database!";
        }else{
        	return "Data doesn't stored in database!";
        }
	}
	public function get_state($id){
		return $this->db->get_where('states',array('country_id'=>$id))->result_array();

	}
    function add_city(){
        $data = array(
                        'name' => $this->input->post('cityname'),
                        'state_id' =>$this->input->post('state'),
                    );
        if($this->db->insert('cities',$data)){
            return "Data stored in databse!";
        }else{
            return "Data doesnt stored in database!";
            }
        }

    public function get_city($id){
        return $this->db->get_where('cities',array('state_id'=>$id))->result_array();

    }
    public function get_data($id){
        $result = $this->db->get_where('countries', array('id' => $id))->row_array();
        return $result;
    }
     public function getRows($params = array()){
        return $this->db->get('countries')->result_array();}
       
   
    public function delete($id){
        if(is_array($id)){
          // print_r($id);exit;
            $this->db->where_in('id', $id);
        }else{
            $this->db->where('id', $id);
        }
        $delete = $this->db->delete('countries');
        return $delete?true:false;
    }
 
}

